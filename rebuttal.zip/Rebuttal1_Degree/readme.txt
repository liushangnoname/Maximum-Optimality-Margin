10 independent trials
Method: RF, OLS, Ridge, PolyRidge, RbfRidge, SPO+, MOM, PolyMOM, RbfMOM
N_train 500, N_test 1000
Fractional Knapsack
degree = 1, 2, 4, 6
no noise at all