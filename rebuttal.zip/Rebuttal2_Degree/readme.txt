10 independent trials
Method: RF, OLS, Ridge, PolyRidge, RbfRidge, SPO+, MOM, PolyMOM, RbfMOM
N_train 200, N_test 1000
Shortest Path
degree = 1, 2, 4, 6
only scale attack, threshold 0.5, power 3.0 (the same as the last sub-figure of Figure 2)