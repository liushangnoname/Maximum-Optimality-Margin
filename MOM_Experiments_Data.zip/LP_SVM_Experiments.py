import numpy as np
import cvxpy as cp
import sklearn
import sklearn.datasets
from sklearn.ensemble import RandomForestRegressor
import gurobipy
import mosek
import matplotlib.pyplot as plt
from multiprocessing import Pool
import LinearProgramMethod as lpm
import DataGeneration as dg
import LearningMethod as lm
import time


if __name__ == "__main__":
    # Generate Samples
    N_train = 1000
    N_valid = 200
    N_test = 1000
    dim_features = 5
    dim_target = 10
    V = np.eye(dim_target, dim_features)
    Theta_true = -np.concatenate((V, np.zeros((dim_target+1, dim_features))), axis=0)
    degree = 1
    additive_noise = 0
    scale_noise = 0
    z_train, c_train, A_train, b_train = dg.GenerateFractionalKnapsack(N_samples=N_train, dim_features=dim_features, dim_target=dim_target, V=V,
                                        degree=degree, additive_noise=additive_noise, scale_noise=scale_noise)
    z_valid, c_valid, A_valid, b_valid = dg.GenerateFractionalKnapsack(N_samples=N_valid, dim_features=dim_features, dim_target=dim_target, V=V,
                                        degree=degree, additive_noise=additive_noise, scale_noise=scale_noise)
    z_test, c_test, A_test, b_test = dg.GenerateFractionalKnapsack(N_samples=N_test, dim_features=dim_features, dim_target=dim_target, V=V,
                                        degree=degree, additive_noise=additive_noise, scale_noise=scale_noise)
    start = time.time()
    basic_train, nonb_train, solution_train = lpm.ComputeBasis(c=c_train, A=A_train, b=b_train)
    basic_valid, nonb_valid, solution_valid = lpm.ComputeBasis(c=c_valid, A=A_valid, b=b_valid)
    basic_test, nonb_test, solution_test = lpm.ComputeBasis(c=c_test, A=A_test, b=b_test)
    print("Time cost", time.time() - start)

    # Random Forest
    print("Method Random Forest")

    regr = RandomForestRegressor(max_depth=2, random_state=0)
    regr.fit(z_train, c_train)
    hat_c = regr.predict(z_test)
    Regret_RF_true, Error_RF = lpm.ComputeRegret(A=A_test, b=b_test, c=c_test, z=z_test, direct=True, hat_c=hat_c, solution=solution_test)
    print("Training samples", N_train)
    print("Regret", np.average(Regret_RF_true), "Error", np.average(Error_RF))

    # Margin Learning
    print("Method SVM Margin Learning")
    print("Training samples", N_train)
    Theta_ML = lm.MarginLearning(A = A_train, b = b_train, z = z_train, basic = basic_train, nonb = nonb_train, regular_const = 1e-3)
    Regret_ML, Error_ML = lpm.ComputeRegret(A = A_test, b = b_test, c = c_test, z = z_test, direct = False, Theta = Theta_ML, solved = True, solution = solution_test)
    print("Regret", np.average(Regret_ML), "Error", np.average(Error_ML))